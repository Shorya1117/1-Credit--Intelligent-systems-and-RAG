#!/usr/bin/env python3
"""
Find the PDF page(s) most similar to a query using TF-IDF and cosine similarity.

Examples:
  python search_pdf.py --pdf book.pdf --query "how do for loops work"
  python search_pdf.py --pdf book.pdf --query "recursion" --top-k 3
  python search_pdf.py --pdf book.pdf --query "machine learning" --min-pages 100
"""
import argparse
import sys
from pathlib import Path

from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def load_pages(pdf_path):
    """Return normalized text for each page; list index 0 represents PDF page 1."""
    path = Path(pdf_path)
    if not path.is_file():
        raise FileNotFoundError(f"PDF file not found: {pdf_path}")

    try:
        reader = PdfReader(str(path))
        pages = []
        for page in reader.pages:
            page_text = page.extract_text() or ""
            pages.append(" ".join(page_text.split()))
        return pages
    except Exception as exc:
        raise RuntimeError(f"Could not read PDF: {exc}") from exc


def search(pages, query, top_k=1):
    """Return (1-based page number, similarity score) results, highest score first."""
    usable = [(i, text) for i, text in enumerate(pages) if text.strip()]
    if not usable:
        return []

    vectorizer = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
        sublinear_tf=True,
    )
    try:
        matrix = vectorizer.fit_transform([text for _, text in usable])
        query_vector = vectorizer.transform([query])
    except ValueError as exc:
        raise ValueError(
            "Could not build search index. Check that the PDF contains readable text "
            "and the query is not empty."
        ) from exc

    scores = cosine_similarity(query_vector, matrix).ravel()
    ranked_indices = scores.argsort()[::-1][:top_k]
    return [
        (usable[int(idx)][0] + 1, float(scores[idx]), usable[int(idx)][1])
        for idx in ranked_indices
    ]


def main():
    parser = argparse.ArgumentParser(
        description="Find the most relevant page in a selectable-text PDF."
    )
    parser.add_argument("--pdf", required=True, help="Path to a selectable-text PDF")
    parser.add_argument("--query", required=True, help="Text describing what you want to find")
    parser.add_argument("--top-k", type=int, default=1, help="Number of matching pages to show")
    parser.add_argument(
        "--max-chars", type=int, default=1500,
        help="Maximum characters of each matching page to print; 0 prints all text",
    )
    parser.add_argument(
        "--min-pages", type=int, default=0,
        help="Optional minimum expected page count (e.g. 100); warns if PDF is shorter",
    )
    args = parser.parse_args()

    if not args.query.strip():
        parser.error("--query cannot be empty")
    if args.top_k < 1:
        parser.error("--top-k must be at least 1")
    if args.max_chars < 0:
        parser.error("--max-chars cannot be negative")

    try:
        pages = load_pages(args.pdf)
        non_empty = sum(bool(page.strip()) for page in pages)
        if len(pages) == 0 or non_empty == 0:
            print("Error: no selectable text found (the PDF may be scanned/image-only).", file=sys.stderr)
            return 2

        print(f"PDF: {args.pdf}")
        print(f"Loaded {len(pages)} pages ({non_empty} pages with selectable text).")
        if args.min_pages and len(pages) < args.min_pages:
            print(f"Warning: PDF has {len(pages)} pages; requested minimum was {args.min_pages}.")
        print(f'Query: {args.query}\n')

        results = search(pages, args.query, args.top_k)
        if not results or results[0][1] <= 0:
            print("No matching page found: none of the query terms matched the PDF text.")
            return 0

        for rank, (page_no, score, page_text) in enumerate(results, start=1):
            if score <= 0:
                continue
            displayed_text = page_text
            if args.max_chars and len(displayed_text) > args.max_chars:
                displayed_text = displayed_text[:args.max_chars].rstrip() + " ..."
            print("=" * 72)
            print(f"Rank {rank} | Page {page_no} | Cosine similarity: {score:.4f}")
            print("=" * 72)
            print(displayed_text)
            print()
        return 0
    except (FileNotFoundError, RuntimeError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())