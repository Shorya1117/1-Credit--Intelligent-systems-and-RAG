# PDF Page Similarity Search — Command-Line Tool

A lightweight CLI utility for finding the page in a text-based PDF that best matches a written query. It extracts page text, ranks pages with TF-IDF and cosine similarity, and displays the strongest match or a list of top results.

The search runs locally, so an API key and `.env` file are not required.

## Search process

1. **Extract:** `pypdf` reads selectable text from each PDF page.
2. **Vectorize:** `scikit-learn` converts page text and the query into TF-IDF vectors using unigrams and bigrams, with English stop words removed.
3. **Compare:** cosine similarity scores each page against the query.
4. **Display:** results include the page number, similarity score, and extracted text.

## Requirements

- Linux with Python 3.9 or newer
- A PDF with selectable text (image-only scans are not supported without OCR)
- `pypdf` and `scikit-learn`

## Set up the environment

On Ubuntu or Debian-based Linux:

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip curl

mkdir -p ~/pdf_search
cd ~/pdf_search
python3 -m venv venv
source venv/bin/activate
```

Create `requirements.txt`:

```text
pypdf
scikit-learn
```

Install the Python dependencies:

```bash
pip install -r requirements.txt
```

## Add a sample PDF

You can use the free book *Think Python* as a test document:

```bash
curl -L -o book.pdf https://greenteapress.com/thinkpython2/thinkpython2.pdf
```

Alternatively, copy a selectable-text PDF of around 100 pages or more into the project folder and name it `book.pdf`.

## Run a search

Basic query:

```bash
python search_pdf.py --pdf book.pdf --query "what is a recursive function"
```

Show the three highest-scoring pages:

```bash
python search_pdf.py --pdf book.pdf --query "dictionaries and hashing" --top-k 3
```

Print all extracted text for the best result:

```bash
python search_pdf.py --pdf book.pdf --query "file handling" --max-chars 0
```

## Command-line options

| Option | Description | Default |
|---|---|---|
| `--pdf` | Path to the PDF file | Required |
| `--query` | Words or question to search for | Required |
| `--top-k` | Number of highest-ranked pages to display | `1` |
| `--max-chars` | Maximum characters of page text to print; `0` prints all text | `1500` |
| `--min-pages` | Optional minimum page-count check, for example `100` | `0` (disabled) |

## Example output

The values below illustrate the output format; your results depend on the PDF and query.

```text
PDF: book.pdf
Loaded 244 pages (240 pages with selectable text).
Query: what is a recursive function

========================================================================
Rank 1 | Page 85 | Cosine similarity: 0.3412
========================================================================
<text extracted from the matching page>
```

## Project layout

```text
pdf_search/
├── search_pdf.py
├── requirements.txt
├── book.pdf
└── README.md
```

## Limitations

- **Keyword-oriented matching:** TF-IDF measures overlap in word usage, not meaning. A query phrased differently from the PDF may receive a low score.
- **Scanned PDFs:** documents without a selectable text layer are not supported until OCR is applied.
- **Text extraction quality:** unusual layouts, tables, and multi-column pages may not extract in reading order.
- **No positive match:** if the query terms do not overlap with the document vocabulary, the tool may report no matching page.

For stronger semantic matching, a future version could use sentence embeddings, but this implementation intentionally keeps the workflow lightweight and offline.
