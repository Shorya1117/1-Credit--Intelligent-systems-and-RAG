#!/usr/bin/env python3
"""
Two AI bots discuss a seeded topic for a fixed number of replies.
Uses the OpenAI Python SDK with any OpenAI-compatible provider (e.g. Groq,
OpenRouter, Gemini-compatible endpoint, or a local Ollama server).

Configure API_KEY, BASE_URL, MODEL, NUM_ITERATIONS, and SEED_MESSAGE in .env.
"""
import os
import sys
import time
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI, RateLimitError, APIConnectionError, APITimeoutError, APIStatusError

load_dotenv()

API_KEY = os.getenv("API_KEY", "").strip()
BASE_URL = os.getenv("BASE_URL", "").strip() or None
MODEL = os.getenv("MODEL", "").strip()
try:
    NUM_ITERATIONS = int(os.getenv("NUM_ITERATIONS", "8"))
    DELAY_SECONDS = float(os.getenv("DELAY_SECONDS", "1"))
except ValueError:
    sys.exit("NUM_ITERATIONS must be an integer and DELAY_SECONDS must be a number.")

SEED_MESSAGE = os.getenv(
    "SEED_MESSAGE",
    "Should AI tools be used in education? Discuss the benefits and risks."
)
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "."))

if not API_KEY or not MODEL:
    sys.exit(
        "Configuration missing. Copy .env.example to .env and set API_KEY and MODEL."
    )
if NUM_ITERATIONS < 1:
    sys.exit("NUM_ITERATIONS must be at least 1.")
if DELAY_SECONDS < 0:
    sys.exit("DELAY_SECONDS cannot be negative.")

client = OpenAI(api_key=API_KEY, base_url=BASE_URL, timeout=45.0, max_retries=0)

BOTS = {
    "Alice": (
        "You are Alice, an optimistic and curious thinker. Explain your reasoning clearly, "
        "build on the other bot's latest point, and ask a useful follow-up when appropriate. "
        "Keep each reply to 2-4 concise sentences. Do not claim to be human."
    ),
    "Bob": (
        "You are Bob, a thoughtful and skeptical thinker. Test assumptions respectfully, "
        "mention trade-offs, and offer counterexamples where useful. Keep each reply to "
        "2-4 concise sentences. Do not claim to be human."
    ),
}

transcript = []  # list of (speaker, message)


def build_messages(bot_name):
    """Build a provider-compatible conversation history for this bot."""
    messages = [{"role": "system", "content": BOTS[bot_name]}]
    for speaker, message in transcript:
        # A bot's previous messages are assistant turns; the other bot is represented as user.
        role = "assistant" if speaker == bot_name else "user"
        messages.append({"role": role, "content": message})
    return messages


def get_reply(bot_name, max_attempts=4):
    """Request a reply with bounded retries for temporary API errors."""
    for attempt in range(1, max_attempts + 1):
        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=build_messages(bot_name),
                temperature=0.7,
                max_tokens=250,
            )
            reply = (response.choices[0].message.content or "").strip()
            if reply:
                return reply
            print(f"[Warning] Empty response; attempt {attempt}/{max_attempts}.")
        except RateLimitError as exc:
            wait = min(5 * attempt, 20)
            print(f"[Rate limit] Waiting {wait}s (attempt {attempt}/{max_attempts}): {exc}")
            time.sleep(wait)
        except (APITimeoutError, APIConnectionError) as exc:
            print(f"[Connection issue] Attempt {attempt}/{max_attempts}: {exc}")
            time.sleep(min(2 * attempt, 8))
        except APIStatusError as exc:
            if exc.status_code in (400, 401, 403, 404):
                raise RuntimeError(
                    f"Non-retryable API error {exc.status_code}: {exc}. "
                    "Check API_KEY, BASE_URL, and MODEL."
                ) from exc
            print(f"[API error {exc.status_code}] Attempt {attempt}/{max_attempts}: {exc}")
            time.sleep(min(2 * attempt, 8))
    return None


def save_transcript():
    """Save the full conversation to a timestamped UTF-8 text file."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    filename = OUTPUT_DIR / f"chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    with filename.open("w", encoding="utf-8") as handle:
        for speaker, message in transcript:
            handle.write(f"[{speaker}]: {message}\n\n")
    return filename


def main():
    first, second = BOTS.keys()
    print(f"Model: {MODEL} | Reply iterations: {NUM_ITERATIONS}")
    print("-" * 72)

    transcript.append((first, SEED_MESSAGE))
    print(f"\n[{first}] (seed): {SEED_MESSAGE}")

    speaker = second
    completed = 0
    try:
        for iteration in range(1, NUM_ITERATIONS + 1):
            reply = get_reply(speaker)
            if reply is None:
                print(f"\nStopped: {speaker} did not return a reply after retries.")
                break
            transcript.append((speaker, reply))
            completed += 1
            print(f"\n[{speaker}] ({iteration}/{NUM_ITERATIONS}): {reply}")
            speaker = first if speaker == second else second
            if DELAY_SECONDS:
                time.sleep(DELAY_SECONDS)
    except RuntimeError as exc:
        print(f"\nError: {exc}", file=sys.stderr)
    finally:
        saved_path = save_transcript()
        print("\n" + "-" * 72)
        print(f"Finished: {completed}/{NUM_ITERATIONS} replies generated.")
        print(f"Transcript saved to: {saved_path.resolve()}")


if __name__ == "__main__":
    main()
