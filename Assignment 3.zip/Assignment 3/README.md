# PDF Retrieval-Augmented Generation (CLI)

A command-line tool that retrieves relevant pages from a PDF and uses a Large Language Model (LLM) to generate answers based on the retrieved content.

This project extends the earlier PDF similarity-search tool (Assignment 1). Instead of displaying only the most relevant pages and their similarity scores, it combines the user query with the retrieved text to create an **augmented prompt** and sends it to an LLM.

The application displays both the augmented prompt and the generated response.

## How It Works

1. Extract text from each PDF page using `pypdf`.
2. Convert the PDF pages and user query into TF-IDF vectors using unigrams and bigrams.
3. Calculate cosine similarity to identify the most relevant pages.
4. Select the top-k pages as context chunks.
5. Build an augmented prompt containing the retrieved context and user question.
6. Send the prompt to an LLM through an OpenAI-compatible API.
7. Display the augmented prompt and generated answer in the terminal.

Retrieval runs locally. An internet connection and API key are required for cloud-based LLM providers. A local Ollama model can be used without an API key.

## Technologies Used

- Python
- PyPDF
- Scikit-learn
- TF-IDF and cosine similarity
- OpenAI Python SDK
- Python-dotenv
- Retrieval-Augmented Generation (RAG)

## Requirements

- Windows 10 or Windows 11
- Python 3.9 or later
- A PDF containing selectable text
- An LLM provider, such as OpenAI, Groq, or Ollama

## Project Structure

```text
pdf_search/
├── pdf_search.py
├── requirements.txt
├── .env.example
├── .env
├── book.pdf
├── README.md
└── venv/
```

**Note:** The `venv/` directory contains the virtual environment and should not be committed to Git.

## Setup on Windows

### 1. Open the project folder

Open PowerShell or the VS Code terminal and navigate to your project directory.

```powershell
cd "$HOME\Downloads\pdf_search2\pdf_search"
```

Adjust the path if your project is stored somewhere else.

### 2. Create a virtual environment

If you already have a working `venv`, skip this step.

```powershell
python -m venv venv
```

### 3. Activate the environment

```powershell
.\venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Then activate the environment again.

### 4. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

The `requirements.txt` file should contain:

```text
pypdf
scikit-learn
openai
python-dotenv
```

If you already have the environment from Assignment 1, install the updated dependencies using the same command.

## Configure the LLM

Create a `.env` file in the project root, alongside `pdf_search.py`.

You can copy the example configuration if `.env.example` exists:

```powershell
Copy-Item .env.example .env
```

Alternatively, create `.env` directly in VS Code.

Choose one of the following configurations.

### Option A: OpenAI

Create an API key at [OpenAI API Keys](https://platform.openai.com/api-keys).

Add the following to `.env`:

```dotenv
LLM_API_KEY=your-openai-api-key
LLM_MODEL=gpt-4o-mini
```

An API key alone does not guarantee access; your account must have the necessary API billing and quota.

### Option B: Groq

Create an API key at [Groq Console](https://console.groq.com/keys).

Add the following to `.env`:

```dotenv
LLM_API_KEY=your-groq-api-key
LLM_BASE_URL=https://api.groq.com/openai/v1
LLM_MODEL=llama-3.3-70b-versatile
```

Verify that the configured model is available to your account.

### Option C: Ollama (Local LLM)

Install Ollama from [ollama.com](https://ollama.com/).

Download a model using PowerShell:

```powershell
ollama pull llama3.2
```

Start Ollama if it is not already running, then configure `.env`:

```dotenv
LLM_BASE_URL=http://localhost:11434/v1
LLM_MODEL=llama3.2
```

No API key is required for the local Ollama setup used here.

**Security:** Never commit your `.env` file or expose your API keys publicly.

Add these entries to `.gitignore`:

```gitignore
.env
venv/
__pycache__/
*.pyc
```

## Add a PDF

Place your PDF inside the project folder and name it `book.pdf`, or provide its actual path when running the program.

For example, you can use the free book *Think Python*:

[Download Think Python](https://greenteapress.com/thinkpython2/thinkpython2.pdf)

If downloading through PowerShell:

```powershell
Invoke-WebRequest `
  -Uri "https://greenteapress.com/thinkpython2/thinkpython2.pdf" `
  -OutFile "book.pdf"
```

The program requires selectable PDF text. Scanned documents without a text layer are not supported.

## Usage

Make sure the virtual environment is activated and the terminal is in the project directory.

Basic command:

```powershell
python pdf_search.py --pdf book.pdf --query "Explain how Python handles file operations"
```

### Available Arguments

| Argument | Description | Default |
|---|---|---|
| `--pdf` | Path to the input PDF | Required |
| `--query` | Question or search query | Required |
| `--top-k` | Number of relevant pages passed to the LLM | 3 |
| `--max-chars` | Maximum characters per page in the prompt; use `0` for no limit | 3000 |
| `--model` | LLM model name | `.env` value or `gpt-4o-mini` |

## Usage Examples

Run the following commands in the VS Code PowerShell terminal from your project directory.

### 1. Search for dictionary operations

```powershell
python pdf_search.py --pdf book.pdf --query "How are dictionaries used for storing and retrieving data?" --top-k 3
```

### 2. Search for hashing concepts

```powershell
python pdf_search.py --pdf book.pdf --query "What is hashing and how does it help in efficient data lookup?" --top-k 5
```

### 3. Search for file management

```powershell
python pdf_search.py --pdf book.pdf --query "How can files be opened, read, written, and closed in Python?" --top-k 3
```

### 4. Search for error handling

```powershell
python pdf_search.py --pdf book.pdf --query "How can exceptions be handled when an operation fails?" --top-k 4
```

### 5. Save the output to a file

```powershell
python pdf_search.py --pdf book.pdf --query "Explain how Python manages dictionaries and hash tables" --top-k 5 > output.txt
```

## Example Output

The following example uses retrieved-page scores from a sample run. The generated answer is illustrative.

```text
Loaded 244 pages (240 containing text).

Retrieved pages: 67 (score 0.0667), 129 (score 0.0641), 45 (score 0.0600)

======================================================================
AUGMENTED PROMPT
======================================================================
Context:
[Page 67]
<retrieved text from page 67>

[Page 129]
<retrieved text from page 129>

[Page 45]
<retrieved text from page 45>

Question: How are dictionaries used for storing and retrieving data?

Answer based only on the context above.

======================================================================
GENERATED RESPONSE (model: openai/gpt-oss-120b)
======================================================================
Dictionaries store information as key-value pairs. They allow values
to be retrieved using their corresponding keys. Hashing can help
implement efficient key-based lookup operations.

The explanation above is illustrative. The actual response depends
on the retrieved PDF content and the selected LLM.
```

## Configure the LLM

For Groq, create an API key at https://console.groq.com/keys and configure `.env` as follows:

```dotenv
LLM_API_KEY=your-groq-api-key
LLM_BASE_URL=https://api.groq.com/openai/v1
LLM_MODEL=openai/gpt-oss-120b
```

The model ID above is suitable only if it is currently available to your Groq account. Check the current model list at https://console.groq.com/docs/models if the API returns `model_not_found`.

Do not commit `.env` or publish your API key.

## Assignment Outcome

This CLI application demonstrates the three main stages of Retrieval-Augmented Generation:

- **Retrieval:** Select relevant PDF pages using TF-IDF and cosine similarity.
- **Augmentation:** Combine the retrieved context with the user's query.
- **Generation:** Send the augmented prompt to an LLM and display the generated answer.
