
#!/usr/bin/env python3
"""
Assignment 3: PDF-based Retrieval-Augmented Generation CLI.

The program extracts text from a PDF, retrieves relevant pages
using TF-IDF similarity, and passes the selected context to an LLM.

Example:
    python search_pdf.py --pdf book.pdf --query "How do loops work?"
    python search_pdf.py --pdf book.pdf --query "recursion" --top-k 3
"""

import argparse
import os
import sys

from dotenv import load_dotenv
from openai import OpenAI
from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


DEFAULT_MODEL = "gpt-4o-mini"

SYSTEM_PROMPT = (
    "You are a helpful assistant. Answer using only the supplied PDF "
    "context. If the context is insufficient, clearly state that the "
    "provided pages do not contain enough information. Mention the "
    "page numbers used in your answer."
)


def get_client():
    """Initialize the LLM client using environment configuration."""
    load_dotenv(override=True)

    endpoint = os.getenv("LLM_BASE_URL") or None
    token = os.getenv("LLM_API_KEY")

    local_server = bool(endpoint) and (
        "localhost" in endpoint or "127.0.0.1" in endpoint
    )

    if not token:
        if local_server:
            token = "not-needed"
        else:
            sys.exit(
                "Error: LLM_API_KEY is missing. "
                "Configure it in your .env file."
            )

    return OpenAI(api_key=token, base_url=endpoint)


def read_pdf(file_path):
    """Extract and normalize the text of each PDF page."""
    try:
        document = PdfReader(file_path)
    except FileNotFoundError:
        sys.exit(f"Error: PDF file not found: {file_path}")
    except Exception as exc:
        sys.exit(f"Error while opening PDF: {exc}")

    page_texts = []
    for pdf_page in document.pages:
        content = pdf_page.extract_text() or ""
        page_texts.append(" ".join(content.split()))

    return page_texts


def retrieve_pages(page_texts, question, count=3):
    """Rank PDF pages by TF-IDF cosine similarity."""
    if count < 1:
        sys.exit("Error: --top-k must be at least 1.")

    available_pages = [
        (index, content)
        for index, content in enumerate(page_texts, start=1)
        if content.strip()
    ]

    if not available_pages:
        return []

    corpus = [content for _, content in available_pages]

    search_model = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
        sublinear_tf=True,
    )

    try:
        document_vectors = search_model.fit_transform(corpus)
    except ValueError:
        return []

    query_vector = search_model.transform([question])
    similarities = cosine_similarity(
        query_vector, document_vectors
    ).ravel()

    ranked_indices = similarities.argsort()[::-1][:count]

    matches = []
    for position in ranked_indices:
        if similarities[position] > 0:
            page_number = available_pages[position][0]
            matches.append(
                (page_number, float(similarities[position]))
            )

    return matches


def create_context(page_texts, matches, char_limit=3000):
    """Prepare retrieved pages as numbered context chunks."""
    context_chunks = []

    for page_number, similarity in matches:
        page_content = page_texts[page_number - 1]

        if char_limit > 0 and len(page_content) > char_limit:
            page_content = page_content[:char_limit] + " ..."

        context_chunks.append((page_number, page_content))

    return context_chunks


def create_prompt(question, context_chunks):
    """Combine the user question with retrieved PDF context."""
    context_text = "\n\n".join(
        f"[Page {number}]\n{content}"
        for number, content in context_chunks
    )

    augmented_prompt = (
        f"Context:\n{context_text}\n\n"
        f"Question: {question}\n\n"
        "Answer based only on the context above."
    )

    return augmented_prompt


def ask_llm(client, model_name, prompt_text):
    """Generate an answer from the augmented prompt."""
    try:
        result = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt_text},
            ],
            temperature=0.2,
        )
    except Exception as exc:
        sys.exit(f"Error: LLM request failed: {exc}")

    answer_text = result.choices[0].message.content
    return answer_text or "The model returned an empty response."


def display_output(prompt_text, answer_text, model_name):
    """Print the augmented prompt and generated answer."""
    separator = "=" * 70

    print(f"\n{separator}")
    print("AUGMENTED PROMPT")
    print(separator)
    print(prompt_text)

    print(f"\n{separator}")
    print(f"GENERATED RESPONSE (model: {model_name})")
    print(separator)
    print(answer_text)


def main():
    cli = argparse.ArgumentParser(
        description="Retrieve PDF context and generate an LLM answer."
    )

    cli.add_argument("--pdf", required=True, help="PDF file path")
    cli.add_argument("--query", required=True, help="Question to ask")
    cli.add_argument(
        "--top-k",
        type=int,
        default=3,
        help="Maximum number of relevant pages (default: 3)",
    )
    cli.add_argument(
        "--max-chars",
        type=int,
        default=3000,
        help="Maximum characters per page; 0 means no limit",
    )
    cli.add_argument(
        "--model",
        default=None,
        help="LLM model name; overrides LLM_MODEL",
    )

    options = cli.parse_args()

    if options.max_chars < 0:
        sys.exit("Error: --max-chars cannot be negative.")

    page_texts = read_pdf(options.pdf)
    nonempty_count = sum(bool(text.strip()) for text in page_texts)

    if nonempty_count == 0:
        sys.exit(
            "Error: no selectable text found. "
            "The PDF may contain scanned pages."
        )

    print(
        f"Loaded {len(page_texts)} pages "
        f"({nonempty_count} containing text).\n"
    )

    matches = retrieve_pages(
        page_texts, options.query, options.top_k
    )

    if not matches:
        sys.exit("No matching page found for this query.")

    print(
        "Retrieved pages: "
        + ", ".join(
            f"{page} (score {score:.4f})"
            for page, score in matches
        )
        + "\n"
    )

    chunks = create_context(
        page_texts, matches, options.max_chars
    )
    prompt_text = create_prompt(options.query, chunks)

    client = get_client()
    model_name = (
        options.model
        or os.getenv("LLM_MODEL")
        or DEFAULT_MODEL
    )

    generated_answer = ask_llm(client, model_name, prompt_text)

    display_output(prompt_text, generated_answer, model_name)


if __name__ == "__main__":
    main()
